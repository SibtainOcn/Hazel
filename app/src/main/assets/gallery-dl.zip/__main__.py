import sys
from gallery_dl import main
sys.exit(main())
